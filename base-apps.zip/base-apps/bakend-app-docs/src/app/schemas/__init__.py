"""APIリクエスト/レスポンス検証のためのPydanticスキーマ。"""

from app.schemas.common import HealthResponse, MessageResponse, ProblemDetails
from app.schemas.sample.sample_agents import (
    SampleChatRequest,
    SampleChatResponse,
)
from app.schemas.sample.sample_file import (
    SampleFileDeleteResponse,
    SampleFileListResponse,
    SampleFileResponse,
    SampleFileUploadResponse,
)
from app.schemas.sample.sample_sessions import (
    SampleDeleteResponse,
    SampleMessageResponse,
    SampleSessionCreateRequest,
    SampleSessionListResponse,
    SampleSessionResponse,
    SampleSessionUpdateRequest,
)
from app.schemas.sample.sample_user import (
    SampleAPIKeyResponse,
    SampleRefreshTokenRequest,
    SampleToken,
    SampleTokenWithRefresh,
    SampleUserCreate,
    SampleUserLogin,
    SampleUserResponse,
)

__all__ = [
    # 共通スキーマ
    "ProblemDetails",
    "HealthResponse",
    "MessageResponse",
    # サンプルユーザースキーマ
    "SampleToken",
    "SampleTokenWithRefresh",
    "SampleRefreshTokenRequest",
    "SampleAPIKeyResponse",
    "SampleUserCreate",
    "SampleUserLogin",
    "SampleUserResponse",
    # ファイルスキーマ
    "SampleFileUploadResponse",
    "SampleFileResponse",
    "SampleFileListResponse",
    "SampleFileDeleteResponse",
    # エージェント/チャットスキーマ
    "SampleChatRequest",
    "SampleChatResponse",
    # セッションスキーマ
    "SampleMessageResponse",
    "SampleSessionResponse",
    "SampleSessionListResponse",
    "SampleSessionCreateRequest",
    "SampleSessionUpdateRequest",
    "SampleDeleteResponse",
]
