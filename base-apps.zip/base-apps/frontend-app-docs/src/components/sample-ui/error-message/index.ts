/**
 * ErrorMessage コンポーネントのエクスポート
 *
 * @module components/ui/error-message
 */
export { ErrorMessage } from "./error-message";
