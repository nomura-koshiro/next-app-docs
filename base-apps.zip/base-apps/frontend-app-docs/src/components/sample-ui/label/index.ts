/**
 * Label コンポーネントのエクスポート
 *
 * @module components/ui/label
 */
export { Label } from "./label";
