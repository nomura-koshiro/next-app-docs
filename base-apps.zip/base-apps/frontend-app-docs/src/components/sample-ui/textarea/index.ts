/**
 * Textarea コンポーネントのエクスポート
 *
 * @module components/ui/textarea
 */
export { Textarea } from "./textarea";
