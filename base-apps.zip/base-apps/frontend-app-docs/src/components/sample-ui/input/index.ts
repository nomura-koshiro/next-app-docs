/**
 * Input コンポーネントのエクスポート
 *
 * @module components/ui/input
 */
export { Input } from "./input";
