/**
 * LoadingSpinner コンポーネントのエクスポート
 *
 * @module components/ui/loading-spinner
 */
export { LoadingSpinner } from "./loading-spinner";
