export { ErrorBoundary } from "./error-boundary";
