import { useMutation, useQueryClient } from "@tanstack/react-query";

import { api } from "@/lib/api-client";
import { MutationConfig } from "@/lib/tanstack-query";
import { logger } from "@/utils/logger";

import type { SendMessageInput, SendMessageOutput } from "../types";
import { sendMessageOutputSchema } from "../types/api";

// ================================================================================
// API関数
// ================================================================================

export const sendMessage = async (input: SendMessageInput): Promise<SendMessageOutput> => {
  const response = await api.post("/api/v1/sample/chat/messages", input);

  return sendMessageOutputSchema.parse(response);
};

// ================================================================================
// Hooks
// ================================================================================

type UseSendMessageOptions = {
  mutationConfig?: MutationConfig<typeof sendMessage>;
};

export const useSendMessage = ({ mutationConfig }: UseSendMessageOptions = {}) => {
  const queryClient = useQueryClient();

  const { onSuccess, ...restConfig } = mutationConfig || {};

  return useMutation({
    onSuccess: (...args) => {
      queryClient.invalidateQueries({ queryKey: ["sample", "chat", "messages"] }).catch((error) => {
        logger.error("チャットメッセージクエリの無効化に失敗しました", error);
      });
      onSuccess?.(...args);
    },
    ...restConfig,
    mutationFn: sendMessage,
  });
};
